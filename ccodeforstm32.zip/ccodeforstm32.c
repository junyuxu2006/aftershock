#include <Arduino.h>
#include <Wire.h>
#include <Arduino_RouterBridge.h>

constexpr uint8_t MPU_ADDR = 0x68;
constexpr unsigned long SAMPLE_INTERVAL_MS = 20; // 50 Hz

void writeMPURegister(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(reg);
  Wire.write(val);
  Wire.endTransmission();
}

bool initMPU() {
  Wire.beginTransmission(MPU_ADDR);
  if (Wire.endTransmission() != 0) {
    return false; // Sensor not responding at 0x68
  }
  writeMPURegister(0x6B, 0x00); // Wake up MPU6050
  writeMPURegister(0x1A, 0x03); // Low-pass filter
  writeMPURegister(0x19, 0x13); // Sample rate divider: 50 Hz
  writeMPURegister(0x1C, 0x00); // Accel range: +/- 2g
  return true;
}

// Optional alert trigger called by Linux when an aftershock is confirmed
bool trigger_alert(bool active) {
  digitalWrite(LED_BUILTIN, active ? HIGH : LOW);
  return active;
}

void setup() {
  Bridge.begin();
  Wire.begin();
  Monitor.begin(115200);

  pinMode(LED_BUILTIN, OUTPUT);
  digitalWrite(LED_BUILTIN, LOW);

  Bridge.provide_safe("trigger_alert", trigger_alert);

  while (!initMPU()) {
    Monitor.println("MPU6050 not detected. Retrying in 1s...");
    delay(1000);
  }
  Monitor.println("MPU6050 initialized successfully.");
}

void loop() {
  static unsigned long lastSample = 0;
  unsigned long now = millis();

  if (now - lastSample >= SAMPLE_INTERVAL_MS) {
    lastSample = now;

    Wire.beginTransmission(MPU_ADDR);
    Wire.write(0x3B); // Accel Xout_H
    Wire.endTransmission(false);
    Wire.requestFrom((uint8_t)MPU_ADDR, (uint8_t)6, (uint8_t)true);

    if (Wire.available() == 6) {
      int16_t rawX = (Wire.read() << 8) | Wire.read();
      int16_t rawY = (Wire.read() << 8) | Wire.read();
      int16_t rawZ = (Wire.read() << 8) | Wire.read();

      constexpr float scale = 9.80665f / 16384.0f;
      float ax = rawX * scale;
      float ay = rawY * scale;
      float az = rawZ * scale;

      // Forward sample frame to Linux via RouterBridge
      Bridge.notify("accel_sample", ax, ay, az);
    }
  }
}